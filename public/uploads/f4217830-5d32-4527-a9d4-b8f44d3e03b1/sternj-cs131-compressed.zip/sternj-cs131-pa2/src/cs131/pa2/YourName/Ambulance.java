package cs131.pa2.YourName;

import cs131.pa2.Abstract.Direction;
import cs131.pa2.Abstract.Vehicle;

public class Ambulance extends Vehicle{

	public Ambulance (String name, Direction direction) {
		super(name, direction, 4);
	}

	@Override
	protected int getDefaultSpeed() {
		return 9;
	}
	
	@Override
    public String toString() {
        return String.format("%s AMBULANCE %s", super.getDirection(), super.getName());
    }
}
