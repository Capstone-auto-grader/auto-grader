package cs131.pa2.YourName;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;
import cs131.pa2.Abstract.Log.Log;



public class PriorityScheduler extends Tunnel {
	//To determine if a tunnel is occupied
    private final Map<Tunnel, Boolean> mapUseFlag = new HashMap<Tunnel, Boolean>();
    //To keep track of which tunnel a vehicle is in, such that the means
    //is internal to this file.
    private final Map<Vehicle, Tunnel> tunnelUsed = new HashMap<Vehicle, Tunnel>();
    //Specified capacity of one does not interfere with the Queue size, it will grow as needed
    private final PriorityQueue<Vehicle> waitingQueue = new PriorityQueue<Vehicle>(1, priorityComparator);
    private final Lock lock = new ReentrantLock();
    //A waiting list for vehicles not yet at the front of the queue
    private final Condition notcurrent = lock.newCondition();
    //For when a vehicle is at the front but all tunnels are 
    //occupied or something stranger is wrong
    private final Condition currentwaiting = lock.newCondition();
    private Collection<Tunnel> tunnels;
    
    public PriorityScheduler(String name, Collection<Tunnel> tunnels, Log log) {
        super(name, log);
        Iterator<Tunnel> iter = tunnels.iterator();
        this.tunnels = tunnels;
        //Initialize all tunnels as available
        while (iter.hasNext()) {
            this.addTunnel(iter.next());
        }
    }
    
    public void addTunnel(Tunnel tunnel) {
        this.mapUseFlag.put(tunnel, false);
    }
    
    public PriorityScheduler(String name) {
        super(name);
    }
    
    @Override
    public boolean tryToEnterInner(Vehicle vehicle){
    		lock.lock();
        waitingQueue.add(vehicle);
        //wait while not at the head of the queue
        //i.e. while there exists a vehicle with 
        //higher priority
        boolean success = false;
        Tunnel usedTunnel = null;
        while(!success) {
	        //while (!waitingQueue.peek().equals(vehicle)){
        		while (!waitingQueue.peek().equals(vehicle) || waitingQueue.peek().getPriority() > vehicle.getPriority() ){
	            try {
	            		// Must signal the rest waiting, for the case that the head of the queue that just woke up
	            		// is not the head of the queue anymore!
	            		notcurrent.signalAll();
	            		notcurrent.await();
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }   
	        }
	        for (Tunnel t: tunnels) {
	        		success = t.tryToEnter(vehicle);
	        		if (success) {
	        			usedTunnel = t;
	        			break;
	        		}
	        }
	        if (success)
	        		break;
	        try {
	        		currentwaiting.await();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        //System.out.println("Adding vehicle "+vehicle+ " to the tunnels used!");
        //assign the vehicle to the tunnel
        tunnelUsed.put(vehicle, usedTunnel);
        //indicate the tunnel is in use
        mapUseFlag.put(usedTunnel, true);
        waitingQueue.poll();
        //wake up threads waiting to
        //arrive at the head of the queue
        notcurrent.signalAll();
        lock.unlock();
        return true;
    }
    
    
    @Override
    public void exitTunnelInner(Vehicle vehicle){
    		lock.lock();
    		//find which tunnel the vehicle is exiting
    		//System.out.println("EXIT tunnel: Getting tunnel for vehicle: "+vehicle);
        Tunnel tunnel = tunnelUsed.get(vehicle);
        //call exitTunnel on the tunnel
        tunnel.exitTunnel(vehicle);
        //indicate the tunnel is no longer in use
        mapUseFlag.put(tunnel, false);
        //wake up the threads at the head of the queue
        //waiting on the tunnel
        currentwaiting.signalAll();
        lock.unlock();
    }
    
    //Use to compare vehicle priorities for the queue to sort the vehicles
    public static Comparator<Vehicle> priorityComparator = new Comparator<Vehicle>(){	
		@Override
		public int compare(Vehicle v_1, Vehicle v_2) {
            return (int) (v_2.getPriority() - v_1.getPriority());
        }
	};
}
