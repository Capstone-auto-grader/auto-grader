package cs131.pa2.Abstract.Log;

//import cs131.pa2.Abstract.Direction;

public enum EventType {
    ENTER_ATTEMPT("trying to enter"),
    ENTER_SUCCESS("entered successfully"),
    ENTER_FAILED("failed to enter"),
    LEAVE_START("leaving"),
    LEAVE_END("left"),
    COMPLETE("has completed"),
    ERROR("error in log"),
    END_TEST("end of test"),
    INTERRUPTED("interrupted");
            
    private final String name;

    private EventType(String name) {
        this.name = name;
    }
        
    /*public String with_parameter(String parameter){
	    	if(this==ENTER_SUCCESS ){
			return String.format(this.name, parameter.trim());
	    }
	    	else {
	    		return this.toString();
	    	}
    }*/

    @Override
    public String toString() {
        return this.name;
    }
}
