package cs131.pa2.YourName;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;
import cs131.pa2.Abstract.Log.Log;



public class PreemptivePriorityScheduler extends Tunnel{    
	// Dimos
	// We need to maintain a condition variable for each tunnel, so that the ambulance
	// can interrupt all vehicles running in this tunnel only (without affecting other tunnels).
	private final Map<Tunnel, Lock> waitingLocks; // waiting indefinitely for an ambulance to pass through a tunnel
	private final Map <Tunnel, Lock> runningLocks; // someone is passing through the tunnel: wait for your wait time
	private final Map<Tunnel, Condition> waitingInsideTunnel;
	private final Map<Tunnel, Condition> runningInsideTunnel;
	    
    //Specified capacity of one does not interfere with the Queue size, it will grow as needed
    private final PriorityQueue<Vehicle> waitingQueue = new PriorityQueue<Vehicle>(1, priorityComparator);
    private final Lock lock = new ReentrantLock();
    //A waiting list for vehicles not yet at the front of the queue
    private final Condition notcurrent = lock.newCondition();
    //For when a vehicle is at the front but all tunnels are 
    //occupied or something stranger is wrong
    private final Condition currentwaiting = lock.newCondition();
    private final Condition waitForOtherAmbulance = lock.newCondition();
    
    private Collection<Tunnel> tunnels;	
	
	public PreemptivePriorityScheduler(String name, Collection<Tunnel> tunnels, Log log) {
        super(name, log);
        Iterator<Tunnel> iter = tunnels.iterator();
        this.tunnels = tunnels;
        this.waitingLocks = new HashMap<Tunnel,Lock>();
        this.waitingInsideTunnel = new HashMap<Tunnel,Condition>();
        this.runningLocks = new HashMap<Tunnel,Lock>();
        this.runningInsideTunnel = new HashMap<Tunnel,Condition>();
        
        //Initialize all tunnels as available
        while (iter.hasNext()) {
            this.addTunnel(iter.next());
            
        }
    }
	
	public Lock getWaitingLock(Tunnel t) {
		return this.waitingLocks.get(t);
	}
	public Lock getRunningLock(Tunnel t) {
		return this.runningLocks.get(t);
	}
	public Condition getWaitingInsideTunnel(Tunnel t) {
		return this.waitingInsideTunnel.get(t);
	}
	public Condition getRunningInsideTunnel(Tunnel t) {
		return this.runningInsideTunnel.get(t);
	}
	
    public void addTunnel(Tunnel tunnel) {
    		Lock waitingLock = new ReentrantLock();
    		this.waitingLocks.put(tunnel, waitingLock);
    		this.waitingInsideTunnel.put(tunnel, waitingLock.newCondition());
    		Lock runningLock = new ReentrantLock();
    		this.runningLocks.put(tunnel, runningLock);
    		this.runningInsideTunnel.put(tunnel, runningLock.newCondition());
    }
    
    public PreemptivePriorityScheduler(String name) {
        super(name);
        this.waitingLocks = new HashMap<Tunnel,Lock>();
        this.waitingInsideTunnel = new HashMap<Tunnel,Condition>();
        this.runningLocks = new HashMap<Tunnel,Lock>();
        this.runningInsideTunnel = new HashMap<Tunnel,Condition>();
    }

	@Override
	public boolean tryToEnterInner(Vehicle vehicle) {
		lock.lock();
		if(vehicle instanceof Ambulance) {
			while(true) {
				for(Tunnel t : tunnels) {
					if(!t.isHasAmbulance()) {
						boolean success = t.tryToEnter(vehicle);
						if(!success) { // something is not right!
							continue;
						}
						vehicle.setTunnel(t);
						t.setHasAmbulance(true);
						this.getRunningLock(t).lock();
						this.getRunningInsideTunnel(t).signalAll(); // tell everyone in this tunnel to pull over!
						this.getRunningLock(t).unlock();
						lock.unlock();
						return true;
					}
				}
				try {
					waitForOtherAmbulance.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
	        }
		}else {
			waitingQueue.add(vehicle);
			boolean success = false;
	        Tunnel usedTunnel = null;
	        while(!success) {
		        while (!waitingQueue.peek().equals(vehicle)){
		            try {
		            		notcurrent.await();
		            } catch (InterruptedException e) {
		                e.printStackTrace();
		            }   
		        }
		        for (Tunnel t: tunnels) {
		        		success = t.tryToEnter(vehicle);
		        		if (success) {
		        			usedTunnel = t;
		        			break;
		        		}
		        }
		        if (success)
		        		break;
		        try {
		        		currentwaiting.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
        		vehicle.setTunnel(usedTunnel);
	        waitingQueue.poll();
	        //wake up threads waiting to
	        //arrive at the head of the queue
	        notcurrent.signalAll();
		}
		lock.unlock();
		return true;
	}

	@Override
	public void exitTunnelInner(Vehicle vehicle) {
		lock.lock();
		Tunnel usedTunnel = vehicle.getTunnel();
		//find which tunnel the vehicle is exiting and call exitTunnel on that tunnel
		usedTunnel.exitTunnel(vehicle);
	    //wake up the threads at the head of the queue
	    //waiting on the tunnel
	    currentwaiting.signalAll();
	    // if exiting vehicle is ambulance, it must notify the other vehicles to keep going
	    // and waiting ambulances to try and enter a tunnel
	    if (vehicle instanceof Ambulance) {
	    		waitForOtherAmbulance.signal();
	    		Lock waitingLock = this.waitingLocks.get(usedTunnel);
	    		Condition waitingInsideTunnel = this.waitingInsideTunnel.get(usedTunnel);
	    		if (waitingLock == null || waitingInsideTunnel == null) {
	    			System.err.println("Lock for tunnel " + usedTunnel  + " not found!");
	    			lock.unlock();
	    			return;
	    		}
	    		waitingLock.lock();
 			waitingInsideTunnel.signalAll();
 			waitingLock.unlock();
 			usedTunnel.setHasAmbulance(false);
	    }
	    lock.unlock();
	}
    
    //Use to compare vehicle priorities for the queue to sort the vehicles
    public static Comparator<Vehicle> priorityComparator = new Comparator<Vehicle>(){	
		@Override
		public int compare(Vehicle v_1, Vehicle v_2) {
            return (int) (v_2.getPriority() - v_1.getPriority());
        }
	};

}
