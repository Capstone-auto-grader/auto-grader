require './room.rb'
require './action.rb'

class Death < Room
    def initialize()
        @enter_prompt = "You died"
        @actions = {
            'init' => Action.new(['quit'], 'what do you want to do?', 'you have to quit'),
        }
        @next = 'quit'
    end
end