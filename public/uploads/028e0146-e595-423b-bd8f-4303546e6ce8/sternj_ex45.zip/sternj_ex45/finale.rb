require './room.rb'
require './action.rb'

class Finale < Room
    def initialize()
        @enter_prompt = <<-EOF
    You find yourself at the party. You are crying
        EOF
        @actions = {
            'init' => Action.new(['quit'], '', '')
        }
        @next = 'quit'
    end
end
