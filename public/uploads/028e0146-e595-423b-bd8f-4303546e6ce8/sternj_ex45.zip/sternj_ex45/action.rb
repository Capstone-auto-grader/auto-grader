require './scan.rb'

class Action
    def initialize( choices, entry_message, invalid_message)
        @choices = choices
        @entry_message = entry_message
        @invalid_message = invalid_message
    end

    # This is the primary method defined for the Action class. It returns 
    # the name of the Action that the player chooses
    def play()
        puts @entry_message

        # For Actions that trap to Death, I want to just display
        # the entry message. I used this length workaround,
        # I then realized that I wanted to explicitly be able
        # to say 'quit' so I threw in that if block
        if @choices.length == 1 && @choices[0] != 'quit'
            return @choices[0]
        end
        
        # Honestly, I just wanted to use a block here. So I abstracted
        # this set of functions twice over, and as it turns out
        # that is super helpful for making custom invalidation messages


        # Not that I used those here
        return Scanner.get_user_choice(@choices) do |len| 
            # @Ari I needed to take the absolute value of len here
            # @Literally anyone else I just like messing with Ari
            while  input = Scanner.get_input_as_num
                # A loop-- gets a number less than or equal to len and
                # greater than or equal to zero
                # Initially I had the range between 0 and len-1,
                # but String.to_i returns 0 for invalid inputs,
                # which is something I wanted to keep looping on
                if (1..len).include?(input)
                    # Yes, that's proper usage
                    break input-1
                end
                puts @invalid_message
            end
        end   
    end
end
