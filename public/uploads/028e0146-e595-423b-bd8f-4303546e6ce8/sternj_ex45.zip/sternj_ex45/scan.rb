module Scanner
    INPUT = '>'

    # Note: choices is an array
    def Scanner.get_user_choice(choices)

        # Does the printing, outsources the parsing
        choices.each_with_index do |choice, index|
            puts "\t#{index+1}. #{choice}"
        end
        input = yield(choices.length)
        return choices[input]
    end

    # I honestly wanted to just keep the parsing and error_handling 
    # as configurable as possible. 
    def Scanner.get_input_as_num()
        printf "#{INPUT} "
        $stdin.gets.chomp.to_i
    end
end
