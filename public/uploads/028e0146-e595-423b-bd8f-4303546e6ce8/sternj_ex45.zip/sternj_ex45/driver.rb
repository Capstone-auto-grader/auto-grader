# Scripter: Sam Stern
# Words by: Gaby Granata (would like to not be contacted)
# Gaby's script is contained within the ZIP file as "script.jpg"
#   Note from me: I don't have good ideas so Gaby helped me out 

["./action.rb",
"./closet.rb",
"./death.rb",
"./disappear.rb",
"./enter.rb",
"./laugh.rb",
"./room.rb",
"./scan.rb",
"./finale.rb"].each do |mod|
    require mod
end

def main()
    #IDEA HERE-- MAP EACH @next VAR TO A FLAG VALUE ('first', 'second', etc)
    rooms = {
        'init' => Enter.new,
        'go right' => Laugh.new,
        'You need to escape' => Closet.new,
        'You try to disappear' => Disappear.new,
        'death' => Death.new,
        'leave' => Finale.new
    }

    current = 'init'

    while out = rooms[current].enter
        if out == 'quit'
            exit(0)
        end
        current = out
    end
end

main()

