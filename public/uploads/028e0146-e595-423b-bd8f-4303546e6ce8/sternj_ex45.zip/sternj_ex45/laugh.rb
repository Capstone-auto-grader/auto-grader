require './room.rb'
require './action.rb'

class Laugh < Room
    def initialize()
        @enter_prompt = <<-EOF
        You hear people cheering and laughing next door.
        You look into the room
        The walls are covered in what may be paintings
        of rotting fruit
        EOF
        @actions = {
            'init' => Action.new(['You need to escape','You step into the room', 'You stand, frozen'], "", "You need to select an option"),
            'You stand, frozen' => Action.new(['init'], "", ""),
            'You step into the room' => Action.new(['death'], 'They\'re staring. They hate you.', "")
        }
        @next = 'You need to escape'
    end
end
