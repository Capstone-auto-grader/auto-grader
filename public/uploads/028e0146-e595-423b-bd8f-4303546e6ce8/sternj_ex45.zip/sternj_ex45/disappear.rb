require './room.rb'
require './action.rb'

class Disappear < Room
    def initialize()
        @enter_prompt = <<-EOF
    There is nothing for you here.
        EOF
        @actions = {
            'init' => Action.new(['stay', 'leave'], "", ""), 
            'stay' => Action.new(['death'], "You feel nothing", "")
        }
        @next = "leave"
    end
end