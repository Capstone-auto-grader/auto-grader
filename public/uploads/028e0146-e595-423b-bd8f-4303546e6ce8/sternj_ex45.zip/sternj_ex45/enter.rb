require './room.rb'
require './action.rb'
class Enter < Room
    def initialize()
        @enter_prompt =  """
        You are alone

        There are voices coming from the door on the left
        """
        @actions = {
            'init' => Action.new(['go right', 'You glance at each door, unsure of what to do'], 'What do you want to do', 'That\'s not a good idea'),
            'You glance at each door, unsure of what to do' => Action.new(['init'], "You stand, frozen", "")
        }
        @next = 'go right'
    end
end
