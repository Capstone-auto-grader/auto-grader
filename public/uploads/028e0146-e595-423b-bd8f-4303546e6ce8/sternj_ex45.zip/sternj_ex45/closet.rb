require './room.rb'
require './action.rb'

class Closet < Room
    def initialize()
        @enter_prompt = <<-EOF
    You enter a storage closet, curled up next to a hose.
    You try to disappear
        EOF
        @actions = {
            'init' => Action.new(['You try to disappear', 'You exit the closet'], "", "You sit in terror, unsure of what to do"),
            'You exit the closet' => Action.new(['pass'], "", "")
        }
        @next = 'You try to disappear'
    end
    
    def enter()
        num_of_times = 0
        while num_of_times < 3
            sup_return = super
            if sup_return == @next
                @enter_prompt = "You can't disappear"
                num_of_times += 1
            elsif sup_return == 'death'
                return 'death'
            else
                return 'go right' #Goes back to first room
            end
        end
        puts "You disappear"
        @next
    end
end