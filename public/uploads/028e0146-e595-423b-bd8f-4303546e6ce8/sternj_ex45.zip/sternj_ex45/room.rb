class Room
    def initialize()
        @enter_prompt = "This has not been initialized"
        # Maps name -> Action
        @actions = {}
        @next = nil
    end

    # The method called on entry to the room. Simply loops 
    # uuntil the user makes a choice leading to the 'next'
    # Room
    def enter()
        puts @enter_prompt
        # The Action performed on entry to the Room is always mapped
        # to 'init'
        action = 'init'

        # loop
        while action != @next
            action = @actions[action].play()
            
            # breaks out of the method on death
            if action == "death"
                return 'death'
            end

            # I specifically use this in Closet's Enter method.
            # there is one option that back-tracks to a previous room,
            # so I called this method as super and caught the 'nil'.
            # Possible improvement: put in a yield statement letting the writer
            # define how they wanted to handle breakinng out of the method 
            # within their Class
            if action == 'pass' 
                return nil
            end
        end
        # At the end of the method, return the @next Room
        @next
    end
end